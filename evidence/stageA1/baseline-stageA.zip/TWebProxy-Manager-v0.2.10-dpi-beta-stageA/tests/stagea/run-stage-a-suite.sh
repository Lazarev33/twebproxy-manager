#!/usr/bin/env bash
# Stage A regression suite: DPI stabilization + release-gate repair.
#
# Usage: run-stage-a-suite.sh [path/to/twebproxy-manager.sh]
#   With no argument the adjacent release manager is tested. Pass the 0.2.9
#   baseline manager to confirm every gate still fails against it.
set -uo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd -P)"
MGR="${1:-$ROOT/twebproxy-manager.sh}"
TESTS="$ROOT/tests/stagea"

declare -a NAMES=(
  "A1 verify-runtime SIGPIPE/pipefail:sa1-verify-runtime-sigpipe.sh:600"
  "A2 STOCK no-state orphan reconcile:sa2-stock-orphan-reconcile.sh:900"
  "A3 DPI state publication:sa3-state-publication.sh:600"
  "A4 DNS prune safety:sa4-dns-prune-safety.sh:600"
  "A5 concurrent DPI mutation:sa5-concurrent-mutation.sh:600"
  "A6 release metadata single source:sa6-release-metadata.sh:300"
)
rc=0
for entry in "${NAMES[@]}"; do
  label="${entry%%:*}"; rest="${entry#*:}"; script="${rest%%:*}"; tmo="${rest##*:}"
  printf '\n===== %s =====\n' "$label"
  if timeout "$tmo" bash "$TESTS/$script" "$MGR"; then
    printf '%s: PASS\n' "$label"
  else
    status=$?
    if (( status == 124 )); then printf '%s: FAIL (timed out after %ss)\n' "$label" "$tmo" >&2
    else printf '%s: FAIL (exit %s)\n' "$label" "$status" >&2; fi
    rc=1
  fi
done
printf '\nstage-a-suite: %s\n' "$( ((rc==0)) && echo 'PASS (A1, A2, A3, A4, A5, A6)' || echo FAIL )"
exit "$rc"
